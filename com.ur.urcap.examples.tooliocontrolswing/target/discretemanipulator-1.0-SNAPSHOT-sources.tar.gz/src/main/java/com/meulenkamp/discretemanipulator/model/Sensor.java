package com.meulenkamp.discretemanipulator.model;

public enum Sensor {
    Left,
    Right,
}

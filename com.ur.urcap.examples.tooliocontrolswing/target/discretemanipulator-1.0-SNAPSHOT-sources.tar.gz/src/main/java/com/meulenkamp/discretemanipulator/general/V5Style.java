package com.meulenkamp.discretemanipulator.general;

import java.awt.*;

public class V5Style extends Style {
	private static final Dimension INPUTFIELD_SIZE = new Dimension(200, 30);

	@Override
	public Dimension getInputfieldSize() {
		return INPUTFIELD_SIZE;
	}
}
